public class Skills
{
  //Variables:
  String name;
  int mpCost;
  
  //Methods:
  public String getName()
  {
    return name;
  }
  public int getMPCost()
  {
    return mpCost;
  }
  public int damage()
  {
    return 15;
  }
}